This is just a sample text for the README of the library.
Here I would fill in with the rest of the preemptive notes on the library.

I suggest importing this library as gmr